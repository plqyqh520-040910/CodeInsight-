from pathlib import Path
import re

from flask import Flask, jsonify, render_template, request

from ai_reviewer import review_with_ai

app = Flask(__name__)


def detect_language(filename, code, selected_language="auto"):
    """
    根据用户选择、文件后缀和代码特征识别编程语言。
    """

    if selected_language and selected_language != "auto":
        return selected_language

    extension = Path(filename).suffix.lower()

    extension_map = {
        ".py": "python",
        ".js": "javascript",
        ".java": "java",
    }

    if extension in extension_map:
        return extension_map[extension]

    code_lower = code.lower()

    # Java 特征
    if (
        "public class" in code_lower
        or "public static void main" in code_lower
        or "system.out.println" in code_lower
    ):
        return "java"

    # JavaScript 特征
    if (
        "console.log" in code_lower
        or "function " in code_lower
        or "const " in code_lower
        or "let " in code_lower
    ):
        return "javascript"

    # Python 特征
    if (
        "def " in code_lower
        or "import " in code_lower
        or "print(" in code_lower
        or "__name__" in code_lower
    ):
        return "python"

    return "unknown"


def create_issue(
    issue_type,
    severity,
    line,
    title,
    description,
    suggestion,
):
    """
    统一生成问题数据。
    """

    return {
        "source": "static",
        "type": issue_type,
        "severity": severity,
        "line": line,
        "title": title,
        "description": description,
        "suggestion": suggestion,
    }


def static_analyze(code, language):
    """
    使用简单规则检查代码。
    当前版本不运行用户代码，只做静态分析。
    """

    issues = []
    lines = code.splitlines()

    for line_number, line in enumerate(lines, start=1):
        stripped_line = line.strip()

        # 规则1：代码行过长
        if len(line) > 100:
            issues.append(
                create_issue(
                    "style",
                    "low",
                    line_number,
                    "代码行过长",
                    f"当前代码行长度为 {len(line)} 个字符，可能影响阅读。",
                    "建议将复杂表达式拆分成多行，每行尽量不超过 100 个字符。",
                )
            )

        # 规则2：TODO 或 FIXME
        if re.search(r"\b(TODO|FIXME)\b", line, re.IGNORECASE):
            issues.append(
                create_issue(
                    "maintainability",
                    "info",
                    line_number,
                    "发现待处理标记",
                    "代码中存在 TODO 或 FIXME 标记，可能表示功能尚未完成。",
                    "发布或提交代码前，请确认待处理内容是否已经完成。",
                )
            )

        # 规则3：疑似硬编码密码或密钥
        secret_pattern = (
            r"""(?i)\b(password|passwd|token|secret|api[_-]?key)\b"""
            r"""\s*=\s*["'][^"']+["']"""
        )

        if re.search(secret_pattern, line):
            issues.append(
                create_issue(
                    "security",
                    "high",
                    line_number,
                    "疑似硬编码敏感信息",
                    "代码中可能直接写入了密码、Token 或 API Key。",
                    "请使用环境变量或配置文件保存敏感信息，并避免上传到公开仓库。",
                )
            )

        # 规则4：危险的 eval 调用
        if re.search(r"\beval\s*\(", line):
            issues.append(
                create_issue(
                    "security",
                    "high",
                    line_number,
                    "检测到 eval 调用",
                    "eval 可能执行不可信字符串，造成代码注入风险。",
                    "建议使用 JSON 解析、字典映射或其他安全的数据处理方式。",
                )
            )

        # 规则5：危险的 exec 调用
        if re.search(r"\bexec\s*\(", line):
            issues.append(
                create_issue(
                    "security",
                    "high",
                    line_number,
                    "检测到 exec 调用",
                    "exec 可以动态执行代码，可能造成严重安全风险。",
                    "避免执行用户输入，改用明确的函数调用或安全解析方案。",
                )
            )

        if language == "python":
            # 规则6：Python 调试输出
            if re.search(r"\bprint\s*\(", line):
                issues.append(
                    create_issue(
                        "maintainability",
                        "info",
                        line_number,
                        "发现 print 调试输出",
                        "生产代码中直接使用 print 可能不利于日志管理。",
                        "正式项目中可以使用 Python logging 模块记录日志。",
                    )
                )

            # 规则7：裸异常捕获
            if re.match(r"^\s*except\s*:\s*$", line):
                issues.append(
                    create_issue(
                        "reliability",
                        "medium",
                        line_number,
                        "捕获了所有异常",
                        "使用 except: 会捕获包括系统退出在内的所有异常。",
                        "建议捕获明确异常，例如 except ValueError:",
                    )
                )

            # 规则8：空的异常处理
            if stripped_line == "pass" and line_number > 1:
                previous_line = lines[line_number - 2].strip()

                if previous_line.startswith("except"):
                    issues.append(
                        create_issue(
                            "reliability",
                            "medium",
                            line_number,
                            "异常被静默忽略",
                            "异常发生后直接使用 pass，可能导致问题难以发现。",
                            "建议记录异常日志，或者返回清晰的错误信息。",
                        )
                    )

            # 规则9：函数参数过多
            function_match = re.match(
                r"^\s*def\s+\w+\s*\((.*?)\)\s*:",
                line,
            )

            if function_match:
                parameter_text = function_match.group(1).strip()

                if parameter_text:
                    parameters = [
                        parameter.strip()
                        for parameter in parameter_text.split(",")
                        if parameter.strip()
                    ]

                    if len(parameters) > 5:
                        issues.append(
                            create_issue(
                                "maintainability",
                                "medium",
                                line_number,
                                "函数参数过多",
                                f"该函数包含 {len(parameters)} 个参数，调用和维护可能比较困难。",
                                "可以将相关参数封装为字典、数据类或配置对象。",
                            )
                        )

        if language == "javascript":
            # 规则10：使用 var
            if re.search(r"\bvar\s+\w+", line):
                issues.append(
                    create_issue(
                        "style",
                        "low",
                        line_number,
                        "使用了 var",
                        "var 存在函数作用域和变量提升问题。",
                        "建议优先使用 const，需要重新赋值时使用 let。",
                    )
                )

            # 规则11：console.log
            if "console.log" in line:
                issues.append(
                    create_issue(
                        "maintainability",
                        "info",
                        line_number,
                        "发现 console.log",
                        "代码中存在调试输出。",
                        "正式发布前删除调试输出，或使用统一日志工具。",
                    )
                )

            # 规则12：宽松相等判断
            if re.search(r"(?<![=!])==(?!=)", line):
                issues.append(
                    create_issue(
                        "reliability",
                        "medium",
                        line_number,
                        "使用了宽松相等运算符",
                        "JavaScript 的 == 会进行隐式类型转换，可能产生意外结果。",
                        "建议使用严格相等运算符 ===。",
                    )
                )

        if language == "java":
            # 规则13：Java 控制台输出
            if "System.out.println" in line:
                issues.append(
                    create_issue(
                        "maintainability",
                        "info",
                        line_number,
                        "发现 System.out.println",
                        "代码中存在控制台调试输出。",
                        "正式项目中建议使用日志框架，例如 SLF4J。",
                    )
                )

            # 规则14：通配符导入
            if re.match(r"^\s*import\s+[\w.]+\.\*\s*;", line):
                issues.append(
                    create_issue(
                        "style",
                        "low",
                        line_number,
                        "使用了通配符导入",
                        "通配符导入会降低依赖关系的清晰度。",
                        "建议明确导入实际使用的类。",
                    )
                )

    # 规则15：文件代码行数
    if len(lines) > 300:
        issues.append(
            create_issue(
                "maintainability",
                "medium",
                0,
                "文件代码行数较多",
                f"当前文件共有 {len(lines)} 行代码，维护成本可能较高。",
                "建议按照功能或模块拆分文件。",
            )
        )

    return issues


def calculate_score(issues):
    """
    根据风险等级计算代码评分。
    """

    deduction = {
        "high": 15,
        "medium": 8,
        "low": 3,
        "info": 1,
    }

    score = 100

    for issue in issues:
        score -= deduction.get(issue["severity"], 0)

    score = max(score, 0)

    if score >= 90:
        level = "优秀"
    elif score >= 80:
        level = "良好"
    elif score >= 60:
        level = "一般"
    else:
        level = "需要改进"

    return score, level


def merge_issues(static_issues, ai_issues):
    """
    合并静态分析和 AI 分析问题。

    同一代码行、同一问题类型只保留一次，
    避免 AI 重复报告静态规则已经发现的问题。
    """

    merged_issues = list(static_issues)

    existing_keys = set()

    for issue in static_issues:
        line = issue.get("line", 0)
        issue_type = issue.get("type", "")

        if line > 0:
            existing_keys.add((line, issue_type))

    for issue in ai_issues:
        line = issue.get("line", 0)
        issue_type = issue.get("type", "")

        issue_key = (line, issue_type)

        if line > 0 and issue_key in existing_keys:
            continue

        merged_issues.append(issue)

        if line > 0:
            existing_keys.add(issue_key)

    return merged_issues


@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/review", methods=["POST"])
def review_code():
    data = request.get_json(silent=True) or {}

    code = data.get("code", "")
    filename = data.get("filename", "")
    selected_language = data.get("language", "auto")

    enable_ai_value = data.get("enable_ai", False)

    enable_ai = enable_ai_value in {
        True,
        1,
        "1",
        "true",
        "True",
    }

    if not code.strip():
        return jsonify(
            {
                "success": False,
                "message": "请输入代码或上传代码文件。",
            }
        ), 400

    if len(code) > 200_000:
        return jsonify(
            {
                "success": False,
                "message": "代码内容过大，请上传较小的代码文件。",
            }
        ), 400

    language = detect_language(
        filename,
        code,
        selected_language,
    )

    language_names = {
        "python": "Python",
        "javascript": "JavaScript",
        "java": "Java",
        "unknown": "未知语言",
    }

    language_display = language_names.get(
        language,
        language,
    )

    # 第一步：执行本地静态规则检测
    static_issues = static_analyze(
        code,
        language,
    )

    # 第二步：根据用户开关决定是否执行 AI 分析
    if enable_ai:
        ai_result = review_with_ai(
            code=code,
            language=language_display,
            static_issues=static_issues,
        )
    else:
        ai_result = {
            "enabled": False,
            "success": False,
            "message": "本次未启用 AI 分析。",
            "summary": "",
            "advantages": [],
            "issues": [],
            "model": "",
        }

    ai_issues = []

    if ai_result.get("success"):
        ai_issues = ai_result.get("issues", [])

    # 第三步：合并并去除重复问题
    all_issues = merge_issues(
        static_issues,
        ai_issues,
    )

    # 第四步：根据全部问题重新计算分数
    score, level = calculate_score(all_issues)

    statistics = {
        "high": 0,
        "medium": 0,
        "low": 0,
        "info": 0,
    }

    for issue in all_issues:
        severity = issue.get(
            "severity",
            "info",
        )

        if severity in statistics:
            statistics[severity] += 1

    if ai_result.get("success"):
        summary = ai_result.get(
            "summary",
            "AI 已完成代码分析。",
        )
    elif enable_ai:
        summary = (
            "AI 分析暂时不可用，"
            "当前报告仍保留完整静态分析结果。"
        )
    else:
        summary = (
            "本次为本地静态规则分析结果，"
            "未启用 AI 智能分析。"
        )

    return jsonify(
        {
            "success": True,
            "data": {
                "language": language_display,
                "language_code": language,
                "score": score,
                "level": level,
                "statistics": statistics,
                "issue_count": len(all_issues),
                "static_issue_count": len(static_issues),
                "ai_issue_count": len(ai_issues),
                "issues": all_issues,
                "summary": summary,
                "advantages": ai_result.get(
                    "advantages",
                    [],
                ),
                "ai": {
                    "enabled": ai_result.get(
                        "enabled",
                        enable_ai,
                    ),
                    "success": ai_result.get(
                        "success",
                        False,
                    ),
                    "message": ai_result.get(
                        "message",
                        "",
                    ),
                    "model": ai_result.get(
                        "model",
                        "",
                    ),
                },
            },
        }
    )


if __name__ == "__main__":
    app.run(debug=True)