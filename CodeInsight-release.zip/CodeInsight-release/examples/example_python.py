import os
import json

password = "123456"
api_key = "sk-test-key"

def get_user_data(a, b, c, d, e, f):
    print("debug information")
    user_input = input("请输入内容：")

    try:
        result = eval(user_input)
        return result
    except:
        pass

def divide_numbers(a, b):
    return a / b

result = divide_numbers(10, 0)
