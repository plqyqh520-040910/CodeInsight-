import java.util.*;

public class ExampleJava {

    private static String password = "123456";

    public static void main(String[] args) {
        System.out.println("程序开始");

        String firstName = new String("Tom");
        String secondName = new String("Tom");

        if (firstName == secondName) {
            System.out.println("名字相同");
        }

        try {
            int result = 10 / 0;
            System.out.println(result);
        } catch (Exception exception) {
        }
    }
}