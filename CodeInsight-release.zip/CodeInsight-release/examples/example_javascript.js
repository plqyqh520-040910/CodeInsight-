var password = "123456";
var apiKey = "test-api-key";

function findUser(users, id) {
    console.log("正在查找用户");

    for (var i = 0; i < users.length; i++) {
        if (users[i].id == id) {
            return users[i];
        }
    }

    return null;
}

const user = findUser([], 1);
console.log(user.name);
