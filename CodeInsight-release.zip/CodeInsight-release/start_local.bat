@echo off
chcp 65001 > nul
title CodeInsight 智能代码审查助手

cd /d "%~dp0"

echo ========================================
echo     CodeInsight 智能代码审查助手
echo ========================================
echo.

if exist "venv\Scripts\activate.bat" (
    call "venv\Scripts\activate.bat"
) else if exist "%USERPROFILE%\venv\Scripts\activate.bat" (
    call "%USERPROFILE%\venv\Scripts\activate.bat"
) else (
    echo 没有找到 Python 虚拟环境。
    echo 请先创建虚拟环境并安装 requirements.txt。
    pause
    exit /b 1
)

if not exist ".env" (
    echo 没有找到 .env 配置文件。
    echo AI 功能可能无法使用。
    echo.
)

echo 正在启动 Flask 服务……
echo 浏览器访问：http://127.0.0.1:5000
echo 按 Ctrl+C 可以停止服务。
echo.

python app.py

pause