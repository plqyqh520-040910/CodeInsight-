\# CodeInsight 智能代码审查助手



CodeInsight 是一个基于 Flask、本地静态规则和 DeepSeek API 开发的智能代码审查工具。



用户可以上传代码文件或直接粘贴代码，系统会自动识别编程语言，检查代码规范、安全风险、逻辑漏洞、性能问题和可维护性问题，并生成可视化审查报告。



\## 项目功能



\- 支持上传 Python、JavaScript、Java 文件

\- 支持直接粘贴代码

\- 自动识别编程语言

\- 本地静态规则检测

\- DeepSeek AI 智能分析

\- 逻辑漏洞和边界条件检测

\- 安全风险检测

\- 性能和可维护性建议

\- 综合代码质量评分

\- 高、中、低风险问题统计

\- 问题等级分布图

\- 按风险等级筛选问题

\- 按静态检测和 AI 分析筛选问题

\- 导出 JSON 审查报告

\- 打印报告或保存为 PDF

\- AI 调用失败时自动降级为静态分析



\## 技术栈



\### 后端



\- Python

\- Flask

\- Requests

\- python-dotenv



\### 前端



\- HTML5

\- CSS3

\- JavaScript

\- Fetch API



\### 代码分析



\- Python 基础语法结构分析

\- 正则表达式静态规则

\- DeepSeek 大模型 API



\## 系统工作流程



```text

用户上传或粘贴代码

&#x20;       ↓

自动识别编程语言

&#x20;       ↓

执行本地静态规则检测

&#x20;       ↓

根据用户选择调用 DeepSeek AI

&#x20;       ↓

解析和校验 AI 返回的 JSON

&#x20;       ↓

合并静态问题与 AI 问题

&#x20;       ↓

计算代码质量评分

&#x20;       ↓

生成可视化审查报告

```



\## 项目目录



```text

code-review-bot

│

├─ app.py

├─ ai\_reviewer.py

├─ requirements.txt

├─ README.md

├─ .env

├─ .env.example

├─ .gitignore

│

├─ examples

│  ├─ example\_python.py

│  ├─ example\_javascript.js

│  └─ ExampleJava.java

│

└─ templates

&#x20;  └─ index.html

```



其中：



\- `app.py`：Flask 后端、静态分析规则和接口

\- `ai\_reviewer.py`：DeepSeek AI 调用和返回结果校验

\- `templates/index.html`：网页界面、报告展示、筛选和导出功能

\- `examples`：三种编程语言的演示代码

\- `.env`：本地 API 配置，不能上传到公开仓库

\- `.env.example`：环境变量配置示例



\## 安装方法



\### 1. 获取项目



下载或克隆项目后，进入项目目录：



```bash

cd code-review-bot

```



\### 2. 创建虚拟环境



Windows：



```bash

python -m venv venv

```



\### 3. 激活虚拟环境



Windows CMD：



```bash

venv\\Scripts\\activate

```



\### 4. 安装依赖



```bash

pip install -r requirements.txt

```



\## 配置 DeepSeek API



复制 `.env.example` 并将文件名修改为 `.env`。



配置内容：



```env

AI\_API\_KEY=你的DeepSeek\_API\_Key

AI\_BASE\_URL=https://api.deepseek.com

AI\_MODEL=填写已经测试成功的模型名称

AI\_TIMEOUT=60

```



注意：



\- API Key 不要填写在 HTML 或 JavaScript 中。

\- `.env` 不要上传到 GitHub。

\- 不要公开展示包含真实 API Key 的截图。

\- 没有 API Key 时，也可以关闭 AI 功能，仅使用本地静态分析。



\## 启动项目



```bash

python app.py

```



浏览器访问：



```text

http://127.0.0.1:5000

```



\## 使用方法



1\. 上传 `.py`、`.js` 或 `.java` 文件，或者直接粘贴代码。

2\. 选择自动识别语言或手动指定语言。

3\. 选择是否启用 DeepSeek AI 智能分析。

4\. 点击“开始代码审查”。

5\. 查看综合评分、风险统计、问题说明和修改建议。

6\. 使用筛选按钮查看不同等级或不同来源的问题。

7\. 导出 JSON 报告，或者通过打印功能保存为 PDF。



\## 本地静态检测规则



\### 通用规则



\- 单行代码过长

\- TODO 和 FIXME 标记

\- 疑似硬编码密码

\- 疑似硬编码 Token 或 API Key

\- eval 调用

\- exec 调用

\- 文件代码行数过多



\### Python



\- print 调试输出

\- 裸异常捕获

\- 异常被静默忽略

\- 函数参数过多



\### JavaScript



\- 使用 var

\- console.log 调试输出

\- 使用宽松相等运算符 `==`



\### Java



\- System.out.println 调试输出

\- 通配符导入



\## AI 分析内容



DeepSeek AI 主要负责检查：



\- 逻辑错误

\- 边界条件

\- 潜在运行时异常

\- 安全风险

\- 性能问题

\- 错误处理

\- 可读性和可维护性



AI 返回内容经过 JSON 解析、字段校验和风险等级校验后，才会合并到最终报告中。



\## 容错设计



系统针对以下情况进行了处理：



\- API Key 缺失

\- API 请求超时

\- 网络连接失败

\- 模型名称错误

\- AI 返回空内容

\- AI 返回内容不是合法 JSON

\- AI 返回字段缺失

\- AI 返回风险等级不正确



AI 调用失败时，系统不会中断整个审查流程，而是自动保留本地静态分析结果。



\## 安全说明



本项目只进行静态分析，不会执行用户上传的代码。



直接运行陌生代码可能产生以下风险：



\- 删除或修改本地文件

\- 读取敏感信息

\- 发起网络请求

\- 执行恶意命令

\- 产生无限循环



未来若增加动态代码执行功能，需要使用容器沙箱、权限隔离和资源限制。



\## 项目不足



\- 当前主要支持单文件代码审查

\- Java 和 JavaScript 的本地检测主要基于规则匹配

\- 无法获取完整项目的上下文

\- AI 分析可能出现误报或漏报

\- 暂未实现用户登录和历史记录

\- 暂未接入 GitHub 仓库和 Pull Request



\## 后续规划



\- 支持多文件和 ZIP 项目分析

\- 增加 Python AST 静态分析规则

\- 接入 GitHub Pull Request

\- 增加用户登录和历史报告

\- 增加代码修复前后对比

\- 增加多模型结果对比

\- 增加规则配置功能

\- 使用安全沙箱进行动态分析



\## 项目用途



本项目主要用于：



\- 学习 Flask Web 开发

\- 学习前后端接口交互

\- 学习大模型 API 调用

\- 学习代码静态分析

\- 个人简历和面试项目展示



\## 免责声明



AI 生成的代码审查结果仅作为辅助建议，不能完全替代人工代码审查、安全审计和专业测试。

