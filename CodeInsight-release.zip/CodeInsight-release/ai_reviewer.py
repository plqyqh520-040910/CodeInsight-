import json
import os
from typing import Any

import requests
from dotenv import load_dotenv


# 读取项目根目录中的 .env
load_dotenv()


def create_failed_result(
    message: str,
    enabled: bool = True,
) -> dict[str, Any]:
    """
    统一生成 AI 调用失败结果。

    AI 调用失败时不会影响静态分析，
    Flask 后端可以继续生成本地审查报告。
    """

    return {
        "enabled": enabled,
        "success": False,
        "message": message,
        "summary": "",
        "advantages": [],
        "issues": [],
        "model": "",
    }


def normalize_line(value: Any) -> int:
    """
    将 AI 返回的行号转换为整数。
    """

    try:
        line = int(value)

        if line < 0:
            return 0

        return line
    except (TypeError, ValueError):
        return 0


def normalize_ai_issues(raw_issues: Any) -> list[dict[str, Any]]:
    """
    检查并整理 AI 返回的问题列表。
    防止模型返回缺少字段或错误类型的数据。
    """

    if not isinstance(raw_issues, list):
        return []

    allowed_severities = {
        "high",
        "medium",
        "low",
        "info",
    }

    normalized_issues = []

    # 防止 AI 一次返回太多问题
    for raw_issue in raw_issues[:20]:
        if not isinstance(raw_issue, dict):
            continue

        severity = str(
            raw_issue.get("severity", "medium")
        ).lower()

        if severity not in allowed_severities:
            severity = "medium"

        issue_type = str(
            raw_issue.get("type", "maintainability")
        ).lower()

        title = str(
            raw_issue.get(
                "title",
                "AI 发现潜在代码问题",
            )
        ).strip()

        description = str(
            raw_issue.get(
                "description",
                "AI 检测到一个可能需要检查的问题。",
            )
        ).strip()

        suggestion = str(
            raw_issue.get(
                "suggestion",
                "建议结合实际业务逻辑进一步检查。",
            )
        ).strip()

        normalized_issues.append(
            {
                "source": "ai",
                "type": issue_type,
                "severity": severity,
                "line": normalize_line(
                    raw_issue.get("line", 0)
                ),
                "title": title,
                "description": description,
                "suggestion": suggestion,
            }
        )

    return normalized_issues


def review_with_ai(
    code: str,
    language: str,
    static_issues: list[dict[str, Any]],
) -> dict[str, Any]:
    """
    调用 DeepSeek API 对代码进行智能审查。

    重点分析：
    1. 逻辑错误
    2. 安全风险
    3. 性能问题
    4. 异常处理
    5. 可维护性
    """

    api_key = os.getenv("AI_API_KEY", "").strip()
    base_url = os.getenv(
        "AI_BASE_URL",
        "https://api.deepseek.com",
    ).strip()
    model = os.getenv(
        "AI_MODEL",
        "deepseek-v4-flash",
    ).strip()

    try:
        timeout = int(
            os.getenv("AI_TIMEOUT", "60")
        )
    except ValueError:
        timeout = 60

    if not api_key:
        return create_failed_result(
            "没有读取到 DeepSeek API Key，"
            "本次仅执行静态规则检测。"
        )

    if not code.strip():
        return create_failed_result(
            "代码内容为空，无法执行 AI 分析。"
        )

    # 避免一次发送过长代码
    max_code_length = 30000

    if len(code) > max_code_length:
        code_for_review = code[:max_code_length]
        code_note = (
            "\n注意：原始代码过长，"
            "本次只分析了前 30000 个字符。"
        )
    else:
        code_for_review = code
        code_note = ""

    # 只把静态问题的必要字段发给 AI
    static_brief = []

    for issue in static_issues[:20]:
        static_brief.append(
            {
                "line": issue.get("line", 0),
                "severity": issue.get(
                    "severity",
                    "info",
                ),
                "title": issue.get(
                    "title",
                    "",
                ),
            }
        )

    static_text = json.dumps(
        static_brief,
        ensure_ascii=False,
        indent=2,
    )

    system_prompt = """
你是一名资深代码审查工程师。

你的任务是分析用户提交的代码，并输出严格合法的 JSON。

请遵守以下要求：

1. 不要执行用户代码。
2. 不要返回 Markdown。
3. 不要使用代码块符号。
4. 不要返回 JSON 以外的任何文字。
5. 不要重复本地静态规则已经明确发现的问题。
6. 只报告有实际价值的问题。
7. 无法确认的问题不要夸大风险。
8. 问题行号无法确定时填写 0。

风险等级只能使用：
high、medium、low、info

问题类型建议使用：
logic、security、performance、reliability、
maintainability、style

必须返回下面的 JSON 结构：

{
  "summary": "对代码的整体评价",
  "advantages": [
    "代码优点1",
    "代码优点2"
  ],
  "issues": [
    {
      "type": "logic",
      "severity": "medium",
      "line": 12,
      "title": "简短的问题标题",
      "description": "问题产生的原因和可能影响",
      "suggestion": "具体、可执行的修改建议"
    }
  ]
}
""".strip()

    user_prompt = f"""
请审查下面的代码。

编程语言：
{language}

本地静态规则已经发现的问题：
{static_text}

请重点分析本地规则不容易发现的内容：

1. 逻辑漏洞和边界条件
2. 潜在运行时异常
3. 安全风险
4. 性能问题
5. 代码结构和可维护性
6. 错误处理是否合理

待审查代码：
{code_for_review}

{code_note}

请严格返回指定 JSON。
""".strip()

    url = (
        f"{base_url.rstrip('/')}"
        "/chat/completions"
    )

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
    }

    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": system_prompt,
            },
            {
                "role": "user",
                "content": user_prompt,
            },
        ],
        "response_format": {
            "type": "json_object",
        },
        "thinking": {
            "type": "disabled",
        },
        "temperature": 0.2,
        "max_tokens": 2500,
        "stream": False,
    }

    try:
        response = requests.post(
            url,
            headers=headers,
            json=payload,
            timeout=timeout,
        )

        if response.status_code != 200:
            error_text = response.text[:300]

            return create_failed_result(
                f"DeepSeek 请求失败，"
                f"状态码：{response.status_code}。"
                f"接口信息：{error_text}"
            )

        response_data = response.json()

        content = (
            response_data
            .get("choices", [{}])[0]
            .get("message", {})
            .get("content", "")
        )

        if not content:
            return create_failed_result(
                "DeepSeek 返回内容为空，"
                "本次仅展示静态分析结果。"
            )

        ai_data = json.loads(content)

        if not isinstance(ai_data, dict):
            return create_failed_result(
                "DeepSeek 返回的数据结构不正确。"
            )

        summary = str(
            ai_data.get(
                "summary",
                "AI 已完成代码审查。",
            )
        ).strip()

        raw_advantages = ai_data.get(
            "advantages",
            [],
        )

        if isinstance(raw_advantages, list):
            advantages = [
                str(item).strip()
                for item in raw_advantages[:5]
                if str(item).strip()
            ]
        else:
            advantages = []

        issues = normalize_ai_issues(
            ai_data.get("issues", [])
        )

        return {
            "enabled": True,
            "success": True,
            "message": "DeepSeek AI 分析完成。",
            "summary": summary,
            "advantages": advantages,
            "issues": issues,
            "model": model,
        }

    except requests.exceptions.Timeout:
        return create_failed_result(
            "DeepSeek 请求超时，"
            "本次仅展示静态分析结果。"
        )

    except requests.exceptions.ConnectionError:
        return create_failed_result(
            "无法连接 DeepSeek，"
            "请检查网络连接。"
        )

    except json.JSONDecodeError:
        return create_failed_result(
            "DeepSeek 返回内容不是有效 JSON，"
            "本次仅展示静态分析结果。"
        )

    except requests.exceptions.RequestException as error:
        return create_failed_result(
            f"DeepSeek 网络请求发生错误：{error}"
        )

    except Exception as error:
        return create_failed_result(
            f"AI 分析发生未知错误：{error}"
        )